/*
============================================
; Title:  Assignment 1.4
; Author: Ashleigh Lyman
; Date:   12 July 2020
; Modified By: Ashleigh Lyman
; Description: assignment 1.4
;===========================================
*/


export interface IPerson {
    firstName: string;
    lastName: string;
}